/* Public portfolio renderer. No GitHub token or admin credentials are used here. */
const root = document.documentElement;
const SAFE_FALLBACK_IMAGE = 'assets/images/profile-placeholder.svg';

// Mark JavaScript readiness only after the page has loaded enough for the public
// site to render. The CSS keeps content visible if a script is blocked or fails.
window.addEventListener('error', () => root.classList.remove('js-ready'), {once:false});

function safeUrl(value, fallback='#'){
  const v = String(value || '').trim();
  if(!v) return fallback;
  if(v.startsWith('#') || v.startsWith('/') || v.startsWith('./') || v.startsWith('../')) return v;
  try{
    const u = new URL(v, window.location.href);
    if(['http:','https:','mailto:'].includes(u.protocol)) return u.href;
  }catch(e){}
  return fallback;
}
function safeImage(value){
  const v = String(value || '').trim();
  if(!v || /^javascript:/i.test(v)) return SAFE_FALLBACK_IMAGE;
  return v;
}
function text(el, value=''){ if(el) el.textContent = value; }

// ---------- Theme ----------
function setTheme(mode){
  const resolved = mode === 'system'
    ? (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light')
    : mode;
  root.setAttribute('data-theme', resolved);
  localStorage.setItem('theme-pref', mode);
  updateThemeIcon();
}
function updateThemeIcon(){
  const icon = document.getElementById('themeIcon');
  if(!icon) return;
  const isDark = root.getAttribute('data-theme') === 'dark';
  icon.innerHTML = isDark
    ? '<path d="M21 12.8A9 9 0 1111.2 3 7 7 0 0021 12.8z"/>'
    : '<circle cx="12" cy="12" r="5"/><path d="M12 1v2M12 21v2M4.2 4.2l1.4 1.4M18.4 18.4l1.4 1.4M1 12h2M21 12h2M4.2 19.8l1.4-1.4M18.4 5.6l1.4-1.4"/>';
}
setTheme(localStorage.getItem('theme-pref') || 'system');
const themeToggle = document.getElementById('themeToggle');
if(themeToggle) themeToggle.addEventListener('click', () => {
  const current = root.getAttribute('data-theme') === 'dark' ? 'dark' : 'light';
  setTheme(current === 'dark' ? 'light' : 'dark');
});

// ---------- Nav / mobile ----------
const nav = document.getElementById('nav');
window.addEventListener('scroll', () => nav && nav.classList.toggle('scrolled', window.scrollY > 40));
const hamburger = document.getElementById('hamburger');
const mobileMenu = document.getElementById('mobileMenu');
if(hamburger && mobileMenu) hamburger.addEventListener('click', () => mobileMenu.classList.toggle('open'));
function closeMobile(){ if(mobileMenu) mobileMenu.classList.remove('open'); }

// ---------- Reveal ----------
function initReveal(){
  const items = document.querySelectorAll('.reveal:not(.is-visible)');
  if(!('IntersectionObserver' in window)){ items.forEach(i=>i.classList.add('is-visible')); return; }
  const obs = new IntersectionObserver(entries => entries.forEach(e=>{
    if(e.isIntersecting){ e.target.classList.add('is-visible'); obs.unobserve(e.target); }
  }), {threshold:.12});
  items.forEach(i=>obs.observe(i));
}

// ---------- Icons ----------
const ICONS = {
  linkedin:'<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M4.98 3.5C4.98 4.88 3.87 6 2.5 6S0 4.88 0 3.5 1.12 1 2.5 1s2.48 1.12 2.48 2.5zM.5 8h4V23h-4V8zM8.5 8h3.8v2.05h.05c.53-1 1.83-2.05 3.77-2.05 4.03 0 4.78 2.65 4.78 6.1V23h-4v-6.98c0-1.66-.03-3.8-2.32-3.8-2.32 0-2.68 1.81-2.68 3.68V23h-4V8z"/></svg>',
  github:'<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M12 .5C5.73.5.5 5.73.5 12a11.5 11.5 0 007.86 10.94c.58.1.79-.25.79-.56v-2c-3.2.7-3.88-1.54-3.88-1.54-.53-1.34-1.29-1.7-1.29-1.7-1.05-.72.08-.7.08-.7 1.17.08 1.78 1.2 1.78 1.2 1.03 1.77 2.72 1.26 3.38.96.1-.75.4-1.26.73-1.55-2.55-.29-5.23-1.28-5.23-5.7 0-1.26.45-2.29 1.19-3.1-.12-.29-.52-1.46.11-3.05 0 0 .97-.31 3.18 1.18a11 11 0 015.79 0c2.2-1.49 3.17-1.18 3.17-1.18.64 1.59.24 2.76.12 3.05.74.81 1.18 1.84 1.18 3.1 0 4.43-2.69 5.4-5.25 5.69.41.36.78 1.06.78 2.14v3.17c0 .31.21.67.8.56A11.5 11.5 0 0023.5 12C23.5 5.73 18.27.5 12 .5z"/></svg>',
  email:'<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="M22 6l-10 7L2 6"/></svg>'
};
function renderSocial(container, site){
  if(!container) return;
  container.replaceChildren();
  const links=[
    ['linkedin',site.linkedin],['github',site.github],['email',site.email ? 'mailto:'+site.email : '']
  ];
  links.forEach(([key,url])=>{
    if(!url) return;
    const a=document.createElement('a'); a.href=safeUrl(url); a.target='_blank'; a.rel='noopener noreferrer'; a.innerHTML=ICONS[key];
    container.appendChild(a);
  });
}

// ---------- Appearance ----------
function applyAppearance(app){
  if(!app) return;
  const c=app.colors||{};
  const map={'--primary':c.primary,'--secondary':c.secondary,'--accent':c.accent,'--bg':c.background,'--surface':c.surface,'--text':c.text,'--text-secondary':c.textSecondary,'--dark-bg':c.darkBackground,'--dark-surface':c.darkSurface,'--dark-accent':c.darkAccent,'--dark-text':c.darkText};
  Object.entries(map).forEach(([k,v])=>{if(v) root.style.setProperty(k,v);});
  if(app.font) root.style.setProperty('--font-body', app.font+', system-ui, sans-serif');
  if(app.headingWeight) root.style.setProperty('--heading-weight',app.headingWeight);
  if(app.cardRadius) root.style.setProperty('--radius',app.cardRadius+'px');
  const img=app.backgroundImage ? safeImage(app.backgroundImage) : '';
  root.style.setProperty('--site-bg-image', img ? `url("${img.replace(/"/g,'')}" )` : 'none');
  root.style.setProperty('--site-overlay-color', app.backgroundOverlay || '#0A0A0B');
  root.style.setProperty('--site-overlay-opacity', String(Math.max(0,Math.min(1,Number(app.backgroundOpacity ?? .1)))));
  root.style.setProperty('--site-bg-position', app.backgroundPosition || 'center');
  const effects=app.effects||{};
  document.querySelectorAll('.botanical-line').forEach(el=>el.style.display=effects.botanicalLines===false?'none':'');
  document.querySelectorAll('.leaf-silhouette').forEach(el=>el.style.display=effects.leafSilhouettes===false?'none':'');
}

// ---------- Header / nav ----------
const CORE_LABELS={home:'Home',about:'About',research:'Research',skills:'Skills',education:'Education'};
function renderNavigation(site, customSections){
  const navCfg=site.nav||{};
  const brandEl=document.getElementById('navBrand');
  if(brandEl){
    brandEl.replaceChildren();
    const brand=String(navCfg.brandText||site.name||'Portfolio').trim();
    const words=brand.split(/\s+/);
    if(words.length>=3){
      const first=document.createElement('span');first.className='brand-main';first.textContent=words.slice(0,-1).join(' ');
      const last=document.createElement('span');last.className='brand-last';last.textContent=words[words.length-1];
      brandEl.append(first,last);
    }else brandEl.textContent=brand;
  }
  const desktop=document.querySelector('.nav-links');
  const mobile=document.getElementById('mobileMenu');
  if(desktop) desktop.replaceChildren();
  if(mobile) mobile.replaceChildren();
  const items=[...(navCfg.items||[])].filter(i=>i && i.visible!==false);
  const known=new Set(items.map(i=>i.id));
  // Any visible custom section automatically becomes available in navigation.
  (customSections||[]).filter(s=>s.visible!==false).sort((a,b)=>(a.order??0)-(b.order??0)).forEach(s=>{
    if(!known.has(s.id) && s.navEnabled!==false) items.push({id:s.id,label:s.navLabel||s.title||s.id,order:1000+(s.order??0),visible:true});
  });
  items.sort((a,b)=>(a.order??0)-(b.order??0));
  const add=(container,item)=>{
    if(!container) return;
    const a=document.createElement('a'); a.href='#'+item.id; a.textContent=item.label||CORE_LABELS[item.id]||item.id;
    a.addEventListener('click',closeMobile); container.appendChild(a);
  };
  items.forEach(i=>{add(desktop,i);add(mobile,i);});
  const showTheme=navCfg.showThemeToggle!==false;
  const showCV=navCfg.showCV!==false;
  const tt=document.getElementById('themeToggle'); if(tt) tt.style.display=showTheme?'flex':'none';
  const cv=document.getElementById('cvBtn');
  if(cv){cv.style.display=showCV?'inline-flex':'none'; cv.textContent=navCfg.cvLabel||'CV'; cv.href=safeUrl(site.cvUrl,'#'); if(!site.cvUrl) cv.setAttribute('aria-disabled','true');}
}

// ---------- Main content ----------
function renderSite(site){
  text(document.getElementById('heroLabel'),site.heroLabel||'');
  text(document.getElementById('heroName'),site.name||'');
  text(document.getElementById('heroTitle'),[site.professionalTitle,site.heroTagline].filter(Boolean).join(' | '));
  text(document.getElementById('heroDesc'),site.heroDescription||'');
  const hero=document.getElementById('heroImage'); if(hero) hero.src=safeImage(site.heroImage);
  text(document.getElementById('footName'),site.name||'');
  text(document.getElementById('footCopy'),'© '+new Date().getFullYear()+' '+(site.name||'')+'. All rights reserved.');
  const btnWrap=document.getElementById('heroButtons'); if(btnWrap) btnWrap.style.display=site.showButtons===false?'none':'flex';
  const p=document.getElementById('heroPrimaryBtn'); if(p){text(p,site.primaryButtonText||'View Research');p.href=safeUrl(site.primaryButtonLink,'#research');}
  const s=document.getElementById('heroSecondaryBtn'); if(s){text(s,site.secondaryButtonText||'Download CV');s.href=safeUrl(site.cvUrl||site.secondaryButtonLink,'#');}
  renderSocial(document.getElementById('heroSocial'),site); renderSocial(document.getElementById('footLinks'),site);
  document.title=(site.name||'Portfolio')+' — Plant Science Researcher';
}
function renderAbout(about){
  text(document.getElementById('aboutHeading'),about.heading||'About Me');
  text(document.getElementById('aboutBio'),about.biography||'');
  const img=document.getElementById('aboutImage'); if(img) img.src=safeImage(about.profileImage);
  const cards=document.getElementById('aboutCards'); if(!cards)return; cards.replaceChildren();
  (about.cards||[]).forEach(c=>{const d=document.createElement('div');d.className='info-card';const l=document.createElement('div');l.className='label';l.textContent=c.label||'';const v=document.createElement('div');v.className='value';v.textContent=c.value||'';d.append(l,v);cards.appendChild(d);});
}
function renderResearch(list){
  const grid=document.getElementById('researchGrid'); if(!grid)return; grid.replaceChildren();
  const sorted=[...(list||[])].sort((a,b)=>(a.order??0)-(b.order??0));
  if(!sorted.length){const empty=document.createElement('div');empty.className='research-empty';empty.innerHTML='<div class="empty-icon">✦</div>';const p=document.createElement('p');p.textContent='Research projects coming soon.';const s=document.createElement('p');s.className='sub-note';s.textContent='New work will appear here as soon as it is added.';empty.append(p,s);grid.appendChild(empty);return;}
  sorted.forEach(r=>{
    const card=document.createElement('article');card.className='research-card reveal';
    const thumb=document.createElement('div');thumb.className='thumb';const img=document.createElement('img');img.src=safeImage(r.image);img.alt=r.title||'Research project';img.loading='lazy';thumb.appendChild(img);
    const body=document.createElement('div');body.className='body';const meta=document.createElement('div');meta.className='meta';const cat=document.createElement('span');cat.textContent=r.category||'';const year=document.createElement('span');year.textContent=r.year||'';meta.append(cat,year);const h=document.createElement('h3');h.textContent=r.title||'Untitled';const p=document.createElement('p');p.textContent=r.description||'';const tags=document.createElement('div');tags.className='research-tags';(r.tags||[]).forEach(t=>{const sp=document.createElement('span');sp.className='tag';sp.textContent=t;tags.appendChild(sp);});body.append(meta,h,p,tags);card.append(thumb,body);grid.appendChild(card);
  }); initReveal();
}
function renderSkills(categories){
  const grid=document.getElementById('skillsGrid'); if(!grid)return; grid.replaceChildren();
  (categories||[]).forEach(cat=>{const d=document.createElement('div');d.className='skill-category reveal';const h=document.createElement('h3');h.textContent=cat.category||'';const wrap=document.createElement('div');wrap.className='skill-pills';(cat.skills||[]).forEach(s=>{const p=document.createElement('span');p.className='pill';p.textContent=s;wrap.appendChild(p);});d.append(h,wrap);grid.appendChild(d);});initReveal();
}
function renderEducation(list){
  const timeline=document.getElementById('timeline'); if(!timeline)return; timeline.replaceChildren();
  (list||[]).forEach(edu=>{const period=[edu.startDate,edu.current?'Present':edu.endDate].filter(Boolean).join(' – ')||'Add information';const item=document.createElement('div');item.className='timeline-item reveal'+(edu.current?' current':'');const dot=document.createElement('div');dot.className='timeline-dot';const card=document.createElement('div');card.className='edu-card';const deg=document.createElement('div');deg.className='degree';deg.textContent=edu.degree||'';if(edu.current){const b=document.createElement('span');b.className='current-badge';b.textContent='Current';deg.appendChild(b);}const inst=document.createElement('div');inst.className='inst';inst.textContent=[edu.institution,edu.location].filter(Boolean).join(', ');const per=document.createElement('div');per.className='period';per.textContent=period;card.append(deg,inst,per);if(edu.description){const p=document.createElement('p');p.className='edu-description';p.textContent=edu.description;card.appendChild(p);}item.append(dot,card);timeline.appendChild(item);});initReveal();
}

function makeDynamicCard(entry){
  const card=document.createElement('article');card.className='list-card reveal';
  if(entry.image){const img=document.createElement('img');img.className='dynamic-card-image';img.src=safeImage(entry.image);img.alt=entry.title||'';img.loading='lazy';card.appendChild(img);}
  if(entry.meta){const meta=document.createElement('div');meta.className='meta';meta.textContent=entry.meta;card.appendChild(meta);}
  const h=document.createElement('h3');h.textContent=entry.title||'';card.appendChild(h);
  if(entry.subtitle){const p=document.createElement('p');p.className='subtitle';p.textContent=entry.subtitle;card.appendChild(p);}
  if(entry.description){const p=document.createElement('p');p.className='desc';p.textContent=entry.description;card.appendChild(p);}
  if(entry.link){const a=document.createElement('a');a.className='list-link';a.href=safeUrl(entry.link);a.target='_blank';a.rel='noopener noreferrer';a.textContent=entry.linkLabel||'View more →';card.appendChild(a);}
  return card;
}
function renderCustomSections(sections){
  const footer=document.querySelector('footer');
  document.querySelectorAll('.custom-dynamic-section').forEach(e=>e.remove());
  const visible=[...(sections||[])].filter(s=>s.visible!==false).sort((a,b)=>(a.order??0)-(b.order??0));
  visible.forEach((s,i)=>{
    const section=document.createElement('section');section.className='dynamic-section custom-dynamic-section '+(i%2?'alt-white':'alt-cream');section.id=s.id;
    const container=document.createElement('div');container.className='container';
    if(s.eyebrow){const e=document.createElement('p');e.className='eyebrow reveal';e.textContent=s.eyebrow;container.appendChild(e);}
    const h=document.createElement('h2');h.className='section-heading reveal';h.textContent=s.heading||s.title||'Section';container.appendChild(h);const rule=document.createElement('div');rule.className='section-rule reveal';container.appendChild(rule);
    if(s.intro){const intro=document.createElement('p');intro.className='dynamic-intro reveal';intro.textContent=s.intro;container.appendChild(intro);}
    const grid=document.createElement('div');grid.className='dynamic-grid';const items=[...(s.items||[])].sort((a,b)=>(a.order??0)-(b.order??0));
    if(!items.length){const empty=document.createElement('div');empty.className='research-empty';const p=document.createElement('p');p.textContent=s.emptyText||'Content coming soon.';empty.appendChild(p);grid.appendChild(empty);}else items.forEach(e=>grid.appendChild(makeDynamicCard(e)));
    container.appendChild(grid);section.appendChild(container);footer.parentNode.insertBefore(section,footer);
  });
  initReveal();
}

// ---------- Boot ----------
(async function(){
  const {site,about,research,skills,education,appearance,sectionsConfig,publications,experience,certificates,customSections}=await loadAllContent();
  applyAppearance(appearance||{});
  renderSite(site||{});
  renderAbout(about||{});renderResearch(research||[]);renderSkills(skills||[]);renderEducation(education||[]);
  renderNavigation(site||{},customSections?.sections||[]);
  // Keep legacy optional sections working, but custom sections are the primary builder.
  const legacyMap={publications,experience,certificates};
  const legacy=(Object.entries(sectionsConfig||{}).filter(([k,v])=>v&&v.visible).map(([k,v])=>({id:k,navLabel:v.navLabel,heading:v.heading,eyebrow:v.eyebrow,emptyText:v.emptyText,visible:true,order:v.order,items:legacyMap[k]||[]})));
  renderCustomSections([...(customSections?.sections||[]),...legacy]);
  initReveal();
  root.classList.add('js-ready');
})().catch(err => {
  console.error('Portfolio initialization failed:', err);
  root.classList.remove('js-ready');
});
