// Loads all content JSON files. Runs on the public site only (relative fetches,
// works natively on GitHub Pages, no token/API needed to READ).
async function loadJSON(path){
  try{
    const res = await fetch(path + '?v=' + Date.now()); // cache-bust so edits show up fast
    if(!res.ok) throw new Error('missing ' + path);
    return await res.json();
  }catch(e){
    console.warn('Could not load', path, e);
    return null;
  }
}

async function loadAllContent(){
  const [site, about, research, skills, education, appearance, sectionsConfig, publications, experience, certificates, customSections] = await Promise.all([
    loadJSON('data/site.json'),
    loadJSON('data/about.json'),
    loadJSON('data/research.json'),
    loadJSON('data/skills.json'),
    loadJSON('data/education.json'),
    loadJSON('data/appearance.json'),
    loadJSON('data/sections-config.json'),
    loadJSON('data/publications.json'),
    loadJSON('data/experience.json'),
    loadJSON('data/certificates.json'),
    loadJSON('data/custom-sections.json')
  ]);
  return { site, about, research, skills, education, appearance, sectionsConfig, publications, experience, certificates, customSections };
}
