/* =========================================================
   Admin Dashboard logic
   All reads/writes go through GH (js/github-api.js) so that
   changes are committed straight to the repo GitHub Pages serves.
   ========================================================= */

const PATHS = {
  site: 'data/site.json',
  about: 'data/about.json',
  research: 'data/research.json',
  skills: 'data/skills.json',
  education: 'data/education.json',
  appearance: 'data/appearance.json'
};

const APPEARANCE_DEFAULT = {
  preset: 'noir',
  colors: {
    primary: '#0B0B0C', secondary: '#C9A227', accent: '#E9C46A',
    background: '#FAF8F3', surface: '#FFFFFF', text: '#1A1712', textSecondary: '#6B6558',
    darkBackground: '#0A0A0B', darkSurface: '#141311', darkAccent: '#D4AF37', darkText: '#F5EFD9'
  },
  font: 'Inter', headingWeight: '700', cardStyle: 'soft', cardRadius: '16',
  effects: { botanicalLines: true, leafSilhouettes: false, scientificGrid: false, molecularDots: true, particles: false }
};

const PRESETS = {
  noir: { name: 'Noir & Gold', ...APPEARANCE_DEFAULT.colors },
  botanical: { name: 'Botanical Green', primary:'#12372A', secondary:'#2F6B4F', accent:'#A8C3A0', background:'#F7F8F4', surface:'#FFFFFF', text:'#17221C', textSecondary:'#66736A', darkBackground:'#0A0A0B', darkSurface:'#111C16', darkAccent:'#6FAF83', darkText:'#F1F5F2' },
  ocean: { name: 'Ocean Blue', primary:'#14324A', secondary:'#2D6FA3', accent:'#9FC6E0', background:'#F5F8FA', surface:'#FFFFFF', text:'#14202A', textSecondary:'#5C707D', darkBackground:'#081016', darkSurface:'#0E1B24', darkAccent:'#6FA9CF', darkText:'#EEF4F8' },
  sage: { name: 'Sage', primary:'#2F3B2C', secondary:'#6B8F5A', accent:'#C8D9BB', background:'#F6F7F2', surface:'#FFFFFF', text:'#232B20', textSecondary:'#6B7566', darkBackground:'#0D110C', darkSurface:'#151C12', darkAccent:'#9BBE86', darkText:'#F0F2EC' },
  earth: { name: 'Earth', primary:'#3B2A1E', secondary:'#8A5A34', accent:'#D8B98C', background:'#FAF6EF', surface:'#FFFFFF', text:'#2A2018', textSecondary:'#7A6C5C', darkBackground:'#120C08', darkSurface:'#1D140D', darkAccent:'#C79D6C', darkText:'#F5EFE6' },
  monochrome: { name: 'Monochrome', primary:'#1C1C1C', secondary:'#4A4A4A', accent:'#C9C9C9', background:'#F5F5F5', surface:'#FFFFFF', text:'#1A1A1A', textSecondary:'#6B6B6B', darkBackground:'#0A0A0A', darkSurface:'#151515', darkAccent:'#B5B5B5', darkText:'#F2F2F2' }
};

let STATE = {
  site: null, about: null, research: [], skills: [], education: [], appearance: null,
  images: [], customSections: [], navItems: []
};

// ---------------- Toast ----------------
function toast(msg, isError){
  const wrap = document.getElementById('toastWrap');
  const el = document.createElement('div');
  el.className = 'toast' + (isError ? ' error' : '');
  el.textContent = msg;
  wrap.appendChild(el);
  setTimeout(() => el.remove(), 4200);
}

// ---------------- Modal ----------------
function openModal(html){
  document.getElementById('modalContent').innerHTML = html;
  document.getElementById('modalBackdrop').classList.add('open');
}
function closeModal(){
  document.getElementById('modalBackdrop').classList.remove('open');
  document.getElementById('modalContent').innerHTML = '';
}
document.getElementById('modalBackdrop').addEventListener('click', (e) => {
  if(e.target.id === 'modalBackdrop') closeModal();
});

// ---------------- Password gate + session security ----------------
const ADMIN_IDLE_MS = 20 * 60 * 1000;
const ADMIN_UNLOCK_KEY = 'admin-unlocked-v2';
let adminIdleTimer = null;

async function sha256Hex(str){
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(str));
  return Array.from(new Uint8Array(buf)).map(b=>b.toString(16).padStart(2,'0')).join('');
}

async function derivePasswordHash(password, saltHex, iterations=150000){
  const enc=new TextEncoder();
  const salt=new Uint8Array((saltHex.match(/.{1,2}/g)||[]).map(h=>parseInt(h,16)));
  const key=await crypto.subtle.importKey('raw',enc.encode(password),'PBKDF2',false,['deriveBits']);
  const bits=await crypto.subtle.deriveBits({name:'PBKDF2',salt,iterations,hash:'SHA-256'},key,256);
  return Array.from(new Uint8Array(bits)).map(b=>b.toString(16).padStart(2,'0')).join('');
}
function randomHex(bytes=16){
  const arr=new Uint8Array(bytes); crypto.getRandomValues(arr);
  return Array.from(arr).map(b=>b.toString(16).padStart(2,'0')).join('');
}
function markAdminActivity(){
  if(sessionStorage.getItem(ADMIN_UNLOCK_KEY)!=='true') return;
  sessionStorage.setItem('admin-last-activity', String(Date.now()));
  clearTimeout(adminIdleTimer);
  adminIdleTimer=setTimeout(lockAdmin, ADMIN_IDLE_MS);
}
function lockAdmin(){
  sessionStorage.removeItem(ADMIN_UNLOCK_KEY);
  sessionStorage.removeItem('admin-last-activity');
  GH.setToken('');
  clearTimeout(adminIdleTimer);
  location.reload();
}
['click','keydown','mousemove','touchstart','scroll'].forEach(evt=>window.addEventListener(evt,markAdminActivity,{passive:true}));

async function initPasswordGate(){
  let accessData={passwordHash:''};
  try{
    const res=await fetch('../data/access.json?v='+Date.now());
    if(res.ok) accessData=await res.json();
  }catch(e){}
  STATE.accessData=accessData;
  const unlocked=sessionStorage.getItem(ADMIN_UNLOCK_KEY)==='true';
  const last=Number(sessionStorage.getItem('admin-last-activity')||0);
  const fresh=last && (Date.now()-last<ADMIN_IDLE_MS);
  if(!accessData.passwordHash){
    // First-run: GitHub must be connected first, then the user creates the password.
    checkSetup();
    return;
  }
  if(unlocked && fresh){ markAdminActivity(); checkSetup(); return; }
  sessionStorage.removeItem(ADMIN_UNLOCK_KEY);
  document.getElementById('passwordScreenTitle').textContent='🔒 Enter dashboard password';
  document.getElementById('passwordScreenText').textContent='Enter your password. This browser session auto-locks after 20 minutes of inactivity.';
  document.getElementById('firstPasswordConfirmWrap').style.display='none';
  document.getElementById('passwordSubmit').textContent='Unlock';
  document.getElementById('passwordInput').autocomplete='current-password';
  document.getElementById('passwordScreen').style.display='flex';
}

document.getElementById('passwordForm').addEventListener('submit',async e=>{
  e.preventDefault();
  const entered=document.getElementById('passwordInput').value;
  const d=STATE.accessData||{};
  const firstRun=!d.passwordHash;
  if(firstRun){
    const confirmPw=document.getElementById('firstPasswordConfirm').value;
    if(entered.length<10){document.getElementById('passwordError').textContent='Use at least 10 characters for the admin password.';document.getElementById('passwordError').style.display='block';return;}
    if(entered!==confirmPw){document.getElementById('passwordError').textContent='Passwords do not match.';document.getElementById('passwordError').style.display='block';return;}
    try{
      const salt=randomHex(16);const hash=await derivePasswordHash(entered,salt,150000);
      STATE.accessData={passwordHash:hash,salt,kdf:'PBKDF2',iterations:150000,version:2};
      await GH.putJSON('data/access.json',STATE.accessData,'Create dashboard password');
      sessionStorage.setItem(ADMIN_UNLOCK_KEY,'true');markAdminActivity();
      document.getElementById('passwordScreen').style.display='none';checkSetup();toast('Admin password created ✓');
    }catch(err){document.getElementById('passwordError').textContent=err.message;document.getElementById('passwordError').style.display='block';}
    return;
  }
  let ok=false;
  try{
    if(d.salt&&d.passwordHash&&d.kdf==='PBKDF2') ok=(await derivePasswordHash(entered,d.salt,d.iterations||150000))===d.passwordHash;
    else ok=(await sha256Hex(entered))===d.passwordHash;
  }catch(err){ok=false;}
  if(ok){sessionStorage.setItem(ADMIN_UNLOCK_KEY,'true');markAdminActivity();document.getElementById('passwordScreen').style.display='none';document.getElementById('passwordInput').value='';checkSetup();}
  else{document.getElementById('passwordError').textContent='Incorrect password. Try again.';document.getElementById('passwordError').style.display='block';}
});

// ---------------- Setup / connection ----------------
function checkSetup(){
  if(!GH.isConfigured()){
    document.getElementById('setupScreen').style.display='flex';
    document.getElementById('adminShell').style.display='none';
    return;
  }
  document.getElementById('setupScreen').style.display='none';
  if(!STATE.accessData?.passwordHash){
    document.getElementById('adminShell').style.display='none';
    document.getElementById('passwordScreenTitle').textContent='🔐 Create your admin password';
    document.getElementById('passwordScreenText').textContent='First-time setup: create a strong password. It will be stored only as a salted PBKDF2 hash in data/access.json.';
    document.getElementById('firstPasswordConfirmWrap').style.display='block';
    document.getElementById('passwordSubmit').textContent='Create password & enter';
    document.getElementById('passwordInput').value='';
    document.getElementById('firstPasswordConfirm').value='';
    document.getElementById('passwordScreen').style.display='flex';
    return;
  }
  document.getElementById('passwordScreen').style.display='none';
  document.getElementById('adminShell').style.display='flex';
  bootDashboard();
}

document.getElementById('setupForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  GH.setConfig({
    owner: document.getElementById('setupOwner').value.trim(),
    repo: document.getElementById('setupRepo').value.trim(),
    branch: document.getElementById('setupBranch').value.trim() || 'main',
    token: document.getElementById('setupToken').value.trim()
  });
  try{
    await GH.testConnection();
    toast('Connected to GitHub ✓');
    checkSetup();
  }catch(err){
    GH.setToken('');
    toast(err.message, true);
  }
});

document.getElementById('testConnectionBtn').addEventListener('click', async () => {
  GH.setConfig({
    owner: document.getElementById('g_owner').value.trim(),
    repo: document.getElementById('g_repo').value.trim(),
    branch: document.getElementById('g_branch').value.trim() || 'main',
    token: document.getElementById('g_token').value.trim() || GH.getConfig().token
  });
  try{ await GH.testConnection(); toast('Connection OK ✓'); }
  catch(err){ GH.setToken(''); toast(err.message, true); }
});

document.getElementById('disconnectBtn').addEventListener('click', () => {
  if(confirm('Remove saved GitHub connection from this browser?')){
    GH.clear();
    sessionStorage.removeItem(ADMIN_UNLOCK_KEY);
    location.reload();
  }
});

// ---------------- Navigation ----------------
document.querySelectorAll('.nav-btn').forEach(btn => {
  btn.addEventListener('click', () => switchView(btn.dataset.view));
});
function switchView(name){
  document.querySelectorAll('.nav-btn').forEach(b => b.classList.toggle('active', b.dataset.view === name));
  document.querySelectorAll('.view').forEach(v => v.classList.toggle('active', v.id === 'view-' + name));
}

// ---------------- Boot ----------------
async function bootDashboard(){
  try{
    const [site, about, research, skills, education, appearance, customSections] = await Promise.all([
      GH.getJSON(PATHS.site), GH.getJSON(PATHS.about), GH.getJSON(PATHS.research),
      GH.getJSON(PATHS.skills), GH.getJSON(PATHS.education), GH.getJSON(PATHS.appearance), GH.getJSON('data/custom-sections.json')
    ]);
    STATE.site = site.data || {};
    STATE.about = about.data || { cards: [] };
    STATE.research = research.data || [];
    STATE.skills = skills.data || [];
    STATE.education = education.data || [];
    STATE.appearance = appearance.data || JSON.parse(JSON.stringify(APPEARANCE_DEFAULT));
    STATE.customSections = (customSections && customSections.data && Array.isArray(customSections.data.sections)) ? customSections.data.sections : [];

    renderOverview();
    fillHomeForm();
    fillHeaderForm();
    fillAboutForm();
    renderResearchTable();
    renderSkills();
    renderEducationTable();
    fillSettingsForm();
    renderAppearance();
    await loadMedia();
    fillHomeForm();
    fillAboutForm();
    renderAppearance();
    loadCustomSections();
    loadOptionalSections();
  }catch(err){
    toast('Failed to load content: ' + err.message, true);
    console.error(err);
  }
}

// ---------------- Overview ----------------
function renderOverview(){
  document.getElementById('statResearch').textContent = STATE.research.length;
  document.getElementById('statSkills').textContent = STATE.skills.reduce((n,c) => n + (c.skills?.length||0), 0);
  document.getElementById('statEducation').textContent = STATE.education.length;
  document.getElementById('statImages').textContent = STATE.images.length || '–';
  document.getElementById('lastUpdated').textContent = STATE.site.lastUpdated
    ? new Date(STATE.site.lastUpdated).toLocaleString()
    : 'No edits saved yet';
}
document.querySelector('[data-action="quick-add-research"]').addEventListener('click', () => { switchView('research'); openResearchModal(); });
document.querySelector('[data-action="quick-add-skill"]').addEventListener('click', () => switchView('skills'));
document.querySelector('[data-action="quick-add-education"]').addEventListener('click', () => { switchView('education'); openEducationModal(); });
document.querySelector('[data-action="quick-edit-home"]').addEventListener('click', () => switchView('home'));

async function touchLastUpdated(){
  STATE.site.lastUpdated = new Date().toISOString();
  await GH.putJSON(PATHS.site, STATE.site, 'Update lastUpdated');
  document.getElementById('lastUpdated').textContent = new Date(STATE.site.lastUpdated).toLocaleString();
}

// =========================================================
// HOME
// =========================================================
function fillHomeForm(){
  const s = STATE.site;
  document.getElementById('h_name').value = s.name || '';
  document.getElementById('h_title').value = s.professionalTitle || '';
  document.getElementById('h_label').value = s.heroLabel || '';
  document.getElementById('h_tagline').value = s.heroTagline || '';
  document.getElementById('h_desc').value = s.heroDescription || '';
  document.getElementById('h_primaryText').value = s.primaryButtonText || '';
  document.getElementById('h_primaryLink').value = s.primaryButtonLink || '';
  document.getElementById('h_secondaryText').value = s.secondaryButtonText || '';
  document.getElementById('h_cvUrl').value = s.cvUrl || '';
  document.getElementById('h_showButtons').checked = s.showButtons !== false;
  document.getElementById('h_linkedin').value = s.linkedin || '';
  document.getElementById('h_github').value = s.github || '';
  document.getElementById('h_email').value = s.email || '';
  const heroSel=document.getElementById('h_heroImage'); heroSel.innerHTML='<option value="">Use placeholder</option>'+STATE.images.map(f=>{const path=`${MEDIA_FOLDER}/${f.name}`;return `<option value="${escapeAttr(path)}">${escapeHtml(f.name)}</option>`;}).join(''); heroSel.value=s.heroImage||'';
}
document.getElementById('saveHome').addEventListener('click', async () => {
  Object.assign(STATE.site, {
    name: val('h_name'), professionalTitle: val('h_title'), heroLabel: val('h_label'),
    heroTagline: val('h_tagline'), heroDescription: val('h_desc'),
    primaryButtonText: val('h_primaryText'), primaryButtonLink: val('h_primaryLink'),
    secondaryButtonText: val('h_secondaryText'), cvUrl: val('h_cvUrl'),
    showButtons: document.getElementById('h_showButtons').checked,
    linkedin: val('h_linkedin'), github: val('h_github'), email: val('h_email'),
    heroImage: document.getElementById('h_heroImage').value,
    siteTitle: val('h_name')
  });
  await saveAndToast(PATHS.site, STATE.site, 'Update home content');
});

function val(id){ return document.getElementById(id).value.trim(); }
async function saveAndToast(path, data, message){
  try{
    STATE.site.lastUpdated = new Date().toISOString();
    if(path !== PATHS.site) await GH.putJSON(PATHS.site, STATE.site, 'Touch lastUpdated');
    await GH.putJSON(path, data, message);
    toast('Saved ✓ — live in a moment');
    renderOverview();
  }catch(err){ toast(err.message, true); }
}

// =========================================================
// HEADER & NAVIGATION
// =========================================================
function fillHeaderForm(){
  const n=STATE.site.nav||{};
  document.getElementById('nav_brandText').value=n.brandText||STATE.site.name||'';
  document.getElementById('nav_shortText').value=n.shortText||'FBS';
  document.getElementById('nav_showTheme').checked=n.showThemeToggle!==false;
  document.getElementById('nav_showCV').checked=n.showCV!==false;
  document.getElementById('nav_cvLabel').value=n.cvLabel||'CV';
  renderNavItems();
}
function renderNavItems(){
  const wrap=document.getElementById('navItemsWrap'); if(!wrap)return; wrap.innerHTML='';
  const items=STATE.site.nav?.items||[];
  items.sort((a,b)=>(a.order??0)-(b.order??0));
  items.forEach((item,i)=>{
    const row=document.createElement('div'); row.className='nav-editor-row';
    row.innerHTML=`<div class="nav-editor-main"><input class="nav-label-input" data-i="${i}" value="${escapeAttr(item.label||'')}"><input class="nav-id-input" data-i="${i}" value="${escapeAttr(item.id||'')}" placeholder="section-id"><label class="checkbox-row"><input type="checkbox" class="nav-visible" data-i="${i}" ${item.visible!==false?'checked':''}> Visible</label></div><div class="row-actions"><button class="icon-btn" data-act="up">↑</button><button class="icon-btn" data-act="down">↓</button><button class="icon-btn danger" data-act="del">🗑</button></div>`;
    row.querySelector('.nav-label-input').addEventListener('change',e=>{items[i].label=e.target.value.trim();});
    row.querySelector('.nav-id-input').addEventListener('change',e=>{items[i].id=e.target.value.trim().replace(/[^a-zA-Z0-9_-]/g,'-');});
    row.querySelector('.nav-visible').addEventListener('change',e=>{items[i].visible=e.target.checked;});
    row.querySelector('[data-act=up]').addEventListener('click',()=>{if(i>0){[items[i-1],items[i]]=[items[i],items[i-1]];items.forEach((x,j)=>x.order=j);renderNavItems();}});
    row.querySelector('[data-act=down]').addEventListener('click',()=>{if(i<items.length-1){[items[i+1],items[i]]=[items[i],items[i+1]];items.forEach((x,j)=>x.order=j);renderNavItems();}});
    row.querySelector('[data-act=del]').addEventListener('click',()=>{if(confirm('Remove this navigation item? This only removes the header link; it does not delete the section.')){items.splice(i,1);items.forEach((x,j)=>x.order=j);renderNavItems();}});
    wrap.appendChild(row);
  });
}
document.getElementById('addNavItem').addEventListener('click',()=>{
  STATE.site.nav=STATE.site.nav||{items:[]}; STATE.site.nav.items=STATE.site.nav.items||[];
  STATE.site.nav.items.push({id:'custom-section',label:'New Link',visible:true,order:STATE.site.nav.items.length}); renderNavItems();
});
document.getElementById('saveHeader').addEventListener('click',async()=>{
  STATE.site.nav=STATE.site.nav||{};
  STATE.site.nav.brandText=val('nav_brandText')||STATE.site.name;
  STATE.site.nav.shortText=val('nav_shortText')||'FBS';
  STATE.site.nav.showThemeToggle=document.getElementById('nav_showTheme').checked;
  STATE.site.nav.showCV=document.getElementById('nav_showCV').checked;
  STATE.site.nav.cvLabel=val('nav_cvLabel')||'CV';
  await saveAndToast(PATHS.site,STATE.site,'Update header and navigation');
});

// =========================================================
// ABOUT
// =========================================================
function fillAboutForm(){
  document.getElementById('a_heading').value = STATE.about.heading || 'About Me';
  document.getElementById('a_bio').value = STATE.about.biography || '';
  const aboutSel=document.getElementById('a_profileImage'); aboutSel.innerHTML='<option value="">Use placeholder</option>'+STATE.images.map(f=>{const path=`${MEDIA_FOLDER}/${f.name}`;return `<option value="${escapeAttr(path)}">${escapeHtml(f.name)}</option>`;}).join(''); aboutSel.value=STATE.about.profileImage||'';
  renderAboutCards();
}
function renderAboutCards(){
  const wrap = document.getElementById('aboutCardsList');
  wrap.innerHTML = '';
  (STATE.about.cards || []).forEach((c, i) => {
    const row = document.createElement('div');
    row.className = 'field-row';
    row.style.marginBottom = '10px';
    row.innerHTML = `
      <input type="text" placeholder="Label" value="${escapeAttr(c.label)}" data-idx="${i}" data-k="label" class="ac-input">
      <input type="text" placeholder="Value" value="${escapeAttr(c.value)}" data-idx="${i}" data-k="value" class="ac-input">
    `;
    const delBtn = document.createElement('button');
    delBtn.type = 'button'; delBtn.className = 'icon-btn danger'; delBtn.innerHTML = '✕';
    delBtn.style.marginLeft = '8px';
    delBtn.addEventListener('click', () => { STATE.about.cards.splice(i,1); renderAboutCards(); });
    row.style.display = 'flex'; row.style.gap='10px'; row.appendChild(delBtn);
    wrap.appendChild(row);
  });
  wrap.querySelectorAll('.ac-input').forEach(inp => {
    inp.addEventListener('input', () => {
      STATE.about.cards[inp.dataset.idx][inp.dataset.k] = inp.value;
    });
  });
}
document.getElementById('addAboutCard').addEventListener('click', () => {
  STATE.about.cards = STATE.about.cards || [];
  STATE.about.cards.push({ label: 'LABEL', value: 'Value' });
  renderAboutCards();
});
document.getElementById('saveAbout').addEventListener('click', async () => {
  STATE.about.heading = val('a_heading');
  STATE.about.biography = document.getElementById('a_bio').value.trim();
  STATE.about.profileImage = document.getElementById('a_profileImage').value;
  await saveAndToast(PATHS.about, STATE.about, 'Update about content');
});

function escapeAttr(s){ return (s||'').toString().replace(/"/g,'&quot;'); }
function escapeHtml(s){ return (s||'').toString().replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }

// =========================================================
// RESEARCH
// =========================================================
function renderResearchTable(){
  const body = document.getElementById('researchTableBody');
  const empty = document.getElementById('researchEmpty');
  body.innerHTML = '';
  const sorted = [...STATE.research].sort((a,b) => (a.order??0) - (b.order??0));
  empty.style.display = sorted.length ? 'none' : 'block';
  sorted.forEach((r) => {
    const realIdx = STATE.research.indexOf(r);
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td><img class="thumb-sm" src="${r.image || '../assets/images/profile-placeholder.svg'}" alt=""></td>
      <td>${escapeHtml(r.title)}</td>
      <td>${escapeHtml(r.category)}</td>
      <td>${escapeHtml(r.year)}</td>
      <td>
        <div class="row-actions">
          <button class="icon-btn" data-act="up" title="Move up">↑</button>
          <button class="icon-btn" data-act="down" title="Move down">↓</button>
          <button class="icon-btn" data-act="dup" title="Duplicate">⧉</button>
          <button class="icon-btn" data-act="edit" title="Edit">✎</button>
          <button class="icon-btn danger" data-act="del" title="Delete">🗑</button>
        </div>
      </td>`;
    tr.querySelector('[data-act=edit]').addEventListener('click', () => openResearchModal(realIdx));
    tr.querySelector('[data-act=del]').addEventListener('click', async () => {
      if(confirm('Delete this research project?')){ STATE.research.splice(realIdx,1); await saveAndToast(PATHS.research, STATE.research, 'Delete research item'); renderResearchTable(); }
    });
    tr.querySelector('[data-act=dup]').addEventListener('click', async () => {
      const copy = JSON.parse(JSON.stringify(r)); copy.title += ' (copy)'; copy.order = STATE.research.length;
      STATE.research.push(copy); await saveAndToast(PATHS.research, STATE.research, 'Duplicate research item'); renderResearchTable();
    });
    tr.querySelector('[data-act=up]').addEventListener('click', async () => { swapOrder(STATE.research, realIdx, -1); await saveAndToast(PATHS.research, STATE.research, 'Reorder research'); renderResearchTable(); });
    tr.querySelector('[data-act=down]').addEventListener('click', async () => { swapOrder(STATE.research, realIdx, 1); await saveAndToast(PATHS.research, STATE.research, 'Reorder research'); renderResearchTable(); });
    body.appendChild(tr);
  });
}

function swapOrder(list, idx, dir){
  const sorted = [...list].sort((a,b) => (a.order??0) - (b.order??0));
  const pos = sorted.indexOf(list[idx]);
  const swapPos = pos + dir;
  if(swapPos < 0 || swapPos >= sorted.length) return;
  const a = sorted[pos], b = sorted[swapPos];
  const tmp = a.order ?? pos; a.order = b.order ?? swapPos; b.order = tmp;
}

function mediaOptions(current=''){
  const opts=['<option value="">No image</option>'];
  STATE.images.forEach(f=>{const path=`${MEDIA_FOLDER}/${f.name}`;opts.push(`<option value="${escapeAttr(path)}" ${path===current?'selected':''}>${escapeHtml(f.name)}</option>`);});
  return opts.join('');
}

function openResearchModal(idx){
  const isEdit = idx !== undefined;
  const r = isEdit ? STATE.research[idx] : { title:'', category:'', year:'', image:'', description:'', methods:'', tags:[], externalUrl:'', pdfUrl:'', githubUrl:'', featured:false, order: STATE.research.length };
  openModal(`
    <h2>${isEdit ? 'Edit' : 'Add'} Research Project</h2>
    <form id="researchForm">
      <div class="field"><label>Title</label><input type="text" id="r_title" value="${escapeAttr(r.title)}"></div>
      <div class="field-row">
        <div class="field"><label>Category</label><input type="text" id="r_category" value="${escapeAttr(r.category)}"></div>
        <div class="field"><label>Year</label><input type="text" id="r_year" value="${escapeAttr(r.year)}"></div>
      </div>
      <div class="field"><label>Research image</label><select id="r_image">${mediaOptions(r.image)}</select><p class="sub" style="margin-top:5px;">Upload images in Media Manager, then select them here.</p></div>
      <div class="field"><label>Description</label><textarea id="r_desc">${escapeHtml(r.description)}</textarea></div>
      <div class="field"><label>Methods</label><textarea id="r_methods">${escapeHtml(r.methods)}</textarea></div>
      <div class="field"><label>Tags <span class="hint">(comma separated)</span></label><input type="text" id="r_tags" value="${escapeAttr((r.tags||[]).join(', '))}"></div>
      <div class="field-row">
        <div class="field"><label>External URL</label><input type="text" id="r_ext" value="${escapeAttr(r.externalUrl)}"></div>
        <div class="field"><label>PDF URL</label><input type="text" id="r_pdf" value="${escapeAttr(r.pdfUrl)}"></div>
      </div>
      <div class="field"><label>GitHub URL</label><input type="text" id="r_gh" value="${escapeAttr(r.githubUrl)}"></div>
      <div class="checkbox-row field"><input type="checkbox" id="r_featured" ${r.featured?'checked':''}><label style="margin:0;">Featured</label></div>
      <div class="modal-actions">
        <button type="button" class="btn btn-outline" id="cancelResearch">Cancel</button>
        <button type="submit" class="btn btn-green">${isEdit?'Save':'Add'} Project</button>
      </div>
    </form>
  `);
  document.getElementById('cancelResearch').addEventListener('click', closeModal);
  document.getElementById('researchForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const data = {
      title: val('r_title'), category: val('r_category'), year: val('r_year'), image: val('r_image'),
      description: document.getElementById('r_desc').value.trim(), methods: document.getElementById('r_methods').value.trim(),
      tags: val('r_tags').split(',').map(t=>t.trim()).filter(Boolean),
      externalUrl: val('r_ext'), pdfUrl: val('r_pdf'), githubUrl: val('r_gh'),
      featured: document.getElementById('r_featured').checked, order: r.order
    };
    if(isEdit) STATE.research[idx] = data; else STATE.research.push(data);
    await saveAndToast(PATHS.research, STATE.research, (isEdit?'Update':'Add') + ' research item');
    renderResearchTable(); closeModal();
  });
}
document.getElementById('addResearchBtn').addEventListener('click', () => openResearchModal());

// =========================================================
// SKILLS
// =========================================================
function renderSkills(){
  const wrap = document.getElementById('skillsCategoriesWrap');
  wrap.innerHTML = '';
  STATE.skills.forEach((cat, ci) => {
    const card = document.createElement('div');
    card.className = 'card';
    card.innerHTML = `
      <div style="display:flex;justify-content:space-between;align-items:center;">
        <input type="text" class="cat-name-input" data-ci="${ci}" value="${escapeAttr(cat.category)}" style="font-weight:700;font-size:1rem;border:none;background:none;padding:4px 0;width:auto;">
        <div class="row-actions">
          <button class="icon-btn" data-act="catup">↑</button>
          <button class="icon-btn" data-act="catdown">↓</button>
          <button class="icon-btn danger" data-act="catdel">🗑</button>
        </div>
      </div>
      <div class="chip-input" style="margin-top:12px;" data-ci="${ci}">
        ${(cat.skills||[]).map((s,si) => `<span class="chip">${escapeHtml(s)}<button type="button" data-ci="${ci}" data-si="${si}" class="skill-del">✕</button></span>`).join('')}
        <input type="text" class="skill-new-input" data-ci="${ci}" placeholder="Add skill + Enter">
      </div>
    `;
    card.querySelector('[data-act=catdel]').addEventListener('click', async () => {
      if(confirm('Delete this category and its skills?')){ STATE.skills.splice(ci,1); await saveAndToast(PATHS.skills, STATE.skills, 'Delete skill category'); renderSkills(); }
    });
    card.querySelector('[data-act=catup]').addEventListener('click', async () => { if(ci>0){ [STATE.skills[ci-1],STATE.skills[ci]]=[STATE.skills[ci],STATE.skills[ci-1]]; await saveAndToast(PATHS.skills, STATE.skills, 'Reorder skills'); renderSkills(); } });
    card.querySelector('[data-act=catdown]').addEventListener('click', async () => { if(ci<STATE.skills.length-1){ [STATE.skills[ci+1],STATE.skills[ci]]=[STATE.skills[ci],STATE.skills[ci+1]]; await saveAndToast(PATHS.skills, STATE.skills, 'Reorder skills'); renderSkills(); } });
    card.querySelector('.cat-name-input').addEventListener('change', async (e) => { STATE.skills[ci].category = e.target.value; await saveAndToast(PATHS.skills, STATE.skills, 'Rename category'); });
    card.querySelectorAll('.skill-del').forEach(btn => btn.addEventListener('click', async () => {
      STATE.skills[ci].skills.splice(+btn.dataset.si,1); await saveAndToast(PATHS.skills, STATE.skills, 'Remove skill'); renderSkills();
    }));
    card.querySelector('.skill-new-input').addEventListener('keydown', async (e) => {
      if(e.key === 'Enter' && e.target.value.trim()){
        e.preventDefault();
        STATE.skills[ci].skills = STATE.skills[ci].skills || [];
        STATE.skills[ci].skills.push(e.target.value.trim());
        await saveAndToast(PATHS.skills, STATE.skills, 'Add skill');
        renderSkills();
      }
    });
    wrap.appendChild(card);
  });
}
document.getElementById('addSkillCatBtn').addEventListener('click', async () => {
  STATE.skills.push({ category: 'New Category', skills: [] });
  await saveAndToast(PATHS.skills, STATE.skills, 'Add skill category');
  renderSkills();
});

// =========================================================
// EDUCATION
// =========================================================
function renderEducationTable(){
  const body = document.getElementById('educationTableBody');
  body.innerHTML = '';
  STATE.education.forEach((edu, i) => {
    const period = [edu.startDate, edu.current ? 'Present' : edu.endDate].filter(Boolean).join(' – ') || 'Add information';
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${escapeHtml(edu.degree)}</td>
      <td>${escapeHtml(edu.institution)}</td>
      <td>${escapeHtml(period)}</td>
      <td><div class="row-actions">
        <button class="icon-btn" data-act="up">↑</button>
        <button class="icon-btn" data-act="down">↓</button>
        <button class="icon-btn" data-act="edit">✎</button>
        <button class="icon-btn danger" data-act="del">🗑</button>
      </div></td>`;
    tr.querySelector('[data-act=edit]').addEventListener('click', () => openEducationModal(i));
    tr.querySelector('[data-act=del]').addEventListener('click', async () => {
      if(confirm('Delete this education entry?')){ STATE.education.splice(i,1); await saveAndToast(PATHS.education, STATE.education, 'Delete education entry'); renderEducationTable(); }
    });
    tr.querySelector('[data-act=up]').addEventListener('click', async () => { if(i>0){ [STATE.education[i-1],STATE.education[i]]=[STATE.education[i],STATE.education[i-1]]; await saveAndToast(PATHS.education, STATE.education, 'Reorder education'); renderEducationTable(); } });
    tr.querySelector('[data-act=down]').addEventListener('click', async () => { if(i<STATE.education.length-1){ [STATE.education[i+1],STATE.education[i]]=[STATE.education[i],STATE.education[i+1]]; await saveAndToast(PATHS.education, STATE.education, 'Reorder education'); renderEducationTable(); } });
    body.appendChild(tr);
  });
}

function openEducationModal(idx){
  const isEdit = idx !== undefined;
  const e = isEdit ? STATE.education[idx] : { degree:'', institution:'', location:'', startDate:'', endDate:'', current:false, description:'', logo:'', website:'' };
  openModal(`
    <h2>${isEdit?'Edit':'Add'} Education</h2>
    <form id="eduForm">
      <div class="field"><label>Degree</label><input type="text" id="e_degree" value="${escapeAttr(e.degree)}"></div>
      <div class="field-row">
        <div class="field"><label>Institution</label><input type="text" id="e_inst" value="${escapeAttr(e.institution)}"></div>
        <div class="field"><label>Location</label><input type="text" id="e_loc" value="${escapeAttr(e.location)}"></div>
      </div>
      <div class="field-row">
        <div class="field"><label>Start date</label><input type="text" id="e_start" value="${escapeAttr(e.startDate)}" placeholder="e.g. Oct 2024"></div>
        <div class="field"><label>End date</label><input type="text" id="e_end" value="${escapeAttr(e.endDate)}" placeholder="Leave blank if current"></div>
      </div>
      <div class="checkbox-row field"><input type="checkbox" id="e_current" ${e.current?'checked':''}><label style="margin:0;">Currently studying here</label></div>
      <div class="field"><label>Description</label><textarea id="e_desc">${escapeHtml(e.description)}</textarea></div>
      <div class="field-row">
        <div class="field"><label>Institution logo</label><select id="e_logo">${mediaOptions(e.logo)}</select></div>
        <div class="field"><label>Website</label><input type="text" id="e_web" value="${escapeAttr(e.website)}"></div>
      </div>
      <div class="modal-actions">
        <button type="button" class="btn btn-outline" id="cancelEdu">Cancel</button>
        <button type="submit" class="btn btn-green">${isEdit?'Save':'Add'}</button>
      </div>
    </form>
  `);
  document.getElementById('cancelEdu').addEventListener('click', closeModal);
  document.getElementById('eduForm').addEventListener('submit', async (ev) => {
    ev.preventDefault();
    const data = {
      degree: val('e_degree'), institution: val('e_inst'), location: val('e_loc'),
      startDate: val('e_start'), endDate: val('e_end'), current: document.getElementById('e_current').checked,
      description: document.getElementById('e_desc').value.trim(), logo: val('e_logo'), website: val('e_web')
    };
    if(isEdit) STATE.education[idx] = data; else STATE.education.push(data);
    await saveAndToast(PATHS.education, STATE.education, (isEdit?'Update':'Add') + ' education entry');
    renderEducationTable(); closeModal();
  });
}
document.getElementById('addEducationBtn').addEventListener('click', () => openEducationModal());

// =========================================================
// MEDIA MANAGER
// =========================================================
const MEDIA_FOLDER = 'assets/images';

async function loadMedia(){
  try{
    const files = await GH.listFolder(MEDIA_FOLDER);
    STATE.images = (Array.isArray(files) ? files : []).filter(f => f.type === 'file' && /\.(png|jpe?g|gif|webp|svg)$/i.test(f.name));
    renderMedia();
    document.getElementById('statImages').textContent = STATE.images.length;
    if(STATE.site) fillHomeForm();
    if(STATE.about) fillAboutForm();
  }catch(err){
    console.warn('Could not list media folder', err);
  }
}

function inferCategory(filename){
  const n = filename.toLowerCase();
  if(n.includes('profile') || n.includes('portrait')) return 'profile';
  if(n.includes('research')) return 'research';
  if(n.includes('edu') || n.includes('logo')) return 'education';
  if(n.includes('background') || n.includes('bg-')) return 'background';
  return 'other';
}

function getImageAssignments(){
  const assignments={hero:STATE.site?.heroImage||'',about:STATE.about?.profileImage||'',background:STATE.appearance?.backgroundImage||''};
  STATE.research.forEach((r,i)=>{if(r.image) assignments['research:'+i]=r.image;});
  STATE.education.forEach((e,i)=>{if(e.logo) assignments['education:'+i]=e.logo;});
  return assignments;
}
function renderMedia(){
  const grid=document.getElementById('mediaGrid'),empty=document.getElementById('mediaEmpty'); if(!grid)return;
  const filter=document.getElementById('mediaFilter').value; grid.innerHTML='';
  const assignments=getImageAssignments();
  const usedPaths=new Set(Object.values(assignments).filter(Boolean));
  document.getElementById('mediaAssignmentSummary').textContent=`${usedPaths.size} assigned · ${STATE.images.length} stored`;
  const list=STATE.images.filter(f=>filter==='all'||inferCategory(f.name)===filter); empty.style.display=list.length?'none':'block';
  list.forEach(f=>{
    const path=`${MEDIA_FOLDER}/${f.name}`; const used=Object.entries(assignments).filter(([,v])=>v===path).map(([k])=>k).join(', ');
    const item=document.createElement('div');item.className='media-item';
    item.innerHTML=`<img src="${escapeAttr(f.download_url)}" alt="${escapeAttr(f.name)}" loading="lazy"><div class="info"><div class="name">${escapeHtml(f.name)}</div><div class="cat">${inferCategory(f.name)}${used?` · Used: ${escapeHtml(used)}`:''}</div></div><div class="actions"><button class="btn btn-outline btn-sm" data-act="hero">Set Home</button><button class="btn btn-outline btn-sm" data-act="about">Set About</button><button class="btn btn-outline btn-sm" data-act="background">Set Background</button><button class="btn btn-outline btn-sm" data-act="replace">Replace</button><button class="btn btn-outline btn-sm" data-act="copy">Copy path</button><button class="btn btn-danger btn-sm" data-act="del">Delete</button><input type="file" class="replace-input" accept="image/jpeg,image/png,image/webp,image/gif" hidden></div>`;
    item.querySelector('[data-act=hero]').addEventListener('click',async()=>{STATE.site.heroImage=path;await saveAndToast(PATHS.site,STATE.site,'Set home image');toast('Home photo updated ✓');});
    item.querySelector('[data-act=about]').addEventListener('click',async()=>{STATE.about.profileImage=path;await saveAndToast(PATHS.about,STATE.about,'Set about image');toast('About photo updated ✓');});
    item.querySelector('[data-act=background]').addEventListener('click',async()=>{STATE.appearance.backgroundImage=path;await saveAndToast(PATHS.appearance,STATE.appearance,'Set background image');renderAppearance();toast('Background updated ✓');});
    item.querySelector('[data-act=copy]').addEventListener('click',()=>navigator.clipboard?.writeText(path).then(()=>toast('Path copied ✓')));
    const input=item.querySelector('.replace-input'); item.querySelector('[data-act=replace]').addEventListener('click',()=>input.click());
    input.addEventListener('change',async e=>{const file=e.target.files[0];if(file) await uploadImageFile(file,path);});
    item.querySelector('[data-act=del]').addEventListener('click',async()=>{if(!confirm(`Delete ${f.name}? If it is assigned, assignments will be cleared first.`))return;try{await clearImageReferences(path);await GH.deleteFile(path,'Delete image via Media Manager');toast('Deleted ✓');await loadMedia();}catch(err){toast(err.message,true);}});
    grid.appendChild(item);
  });
}

document.getElementById('mediaFilter').addEventListener('change', renderMedia);

async function uploadImageFile(file, targetPath=''){
  const allowed=['image/jpeg','image/png','image/webp','image/gif'];
  if(!allowed.includes(file.type)){toast('Use JPG, PNG, WEBP or GIF.',true);return;}
  if(file.size>5*1024*1024){toast('Please use images under 5 MB.',true);return;}
  const reader=new FileReader();
  return new Promise((resolve)=>{
    reader.onload=async()=>{
      const base64=reader.result.split(',')[1];
      const cleanName=(targetPath?targetPath.split('/').pop():file.name).replace(/[^a-zA-Z0-9._-]/g,'-').toLowerCase();
      const path=targetPath||`${MEDIA_FOLDER}/${cleanName}`;
      if(!confirm(`Upload/replace ${cleanName}?`)){resolve(false);return;}
      try{await GH.putBinaryBase64(path,base64,targetPath?'Replace image via Media Manager':'Upload image via Media Manager');toast(targetPath?'Replaced ✓':'Uploaded ✓');await loadMedia();resolve(true);}catch(err){toast(err.message,true);resolve(false);}
    }; reader.readAsDataURL(file);
  });
}

document.getElementById('mediaUploadInput').addEventListener('change',async e=>{const file=e.target.files[0];if(file)await uploadImageFile(file);e.target.value='';});

async function clearImageReferences(path){
  let changed=false;
  if(STATE.site.heroImage===path){STATE.site.heroImage='';changed=true;await GH.putJSON(PATHS.site,STATE.site,'Clear deleted hero image');}
  if(STATE.about.profileImage===path){STATE.about.profileImage='';changed=true;await GH.putJSON(PATHS.about,STATE.about,'Clear deleted about image');}
  if(STATE.appearance.backgroundImage===path){STATE.appearance.backgroundImage='';changed=true;await GH.putJSON(PATHS.appearance,STATE.appearance,'Clear deleted background image');}
  let researchChanged=false; STATE.research.forEach(r=>{if(r.image===path){r.image='';researchChanged=true;changed=true;}}); if(researchChanged) await GH.putJSON(PATHS.research,STATE.research,'Clear deleted research image');
  let educationChanged=false; STATE.education.forEach(e=>{if(e.logo===path){e.logo='';educationChanged=true;changed=true;}}); if(educationChanged) await GH.putJSON(PATHS.education,STATE.education,'Clear deleted education logo');
  let customChanged=false; STATE.customSections.forEach(sec=>(sec.items||[]).forEach(item=>{if(item.image===path){item.image='';customChanged=true;changed=true;}})); if(customChanged) await saveCustomSections();
  return changed;
}

// =========================================================
// APPEARANCE
// =========================================================
const COLOR_FIELDS = [
  ['primary','Primary'], ['secondary','Secondary'], ['accent','Accent'],
  ['background','Background'], ['surface','Surface'], ['text','Text'], ['textSecondary','Secondary text']
];
const EFFECT_FIELDS = [
  ['botanicalLines','Botanical line art'], ['leafSilhouettes','Leaf silhouettes'],
  ['scientificGrid','Scientific grid'], ['molecularDots','Molecular dots'], ['particles','Subtle particles']
];

function renderAppearance(){
  const app = STATE.appearance;
  // presets
  const presetGrid = document.getElementById('presetGrid');
  presetGrid.innerHTML = '';
  Object.entries(PRESETS).forEach(([key, preset]) => {
    const card = document.createElement('div');
    card.className = 'preset-card' + (app.preset === key ? ' active' : '');
    card.innerHTML = `<div class="preset-swatch" style="background:linear-gradient(135deg, ${preset.primary}, ${preset.secondary}, ${preset.accent});"></div><div class="name">${preset.name}</div>`;
    card.addEventListener('click', () => {
      app.preset = key;
      app.colors = { primary: preset.primary, secondary: preset.secondary, accent: preset.accent, background: preset.background, surface: preset.surface, text: preset.text, textSecondary: preset.textSecondary, darkBackground: preset.darkBackground, darkSurface: preset.darkSurface, darkAccent: preset.darkAccent, darkText: preset.darkText };
      renderAppearance();
    });
    presetGrid.appendChild(card);
  });

  // color pickers
  const colorWrap = document.getElementById('colorPickers');
  colorWrap.innerHTML = '';
  COLOR_FIELDS.forEach(([key, label]) => {
    const div = document.createElement('div');
    div.className = 'color-field';
    div.innerHTML = `<label style="margin:0;">${label}</label><input type="color" value="${app.colors[key] || '#000000'}" data-key="${key}">`;
    div.querySelector('input').addEventListener('input', (e) => { app.colors[key] = e.target.value; });
    colorWrap.appendChild(div);
  });

  document.getElementById('ap_font').value = app.font || 'Inter';
  document.getElementById('ap_weight').value = app.headingWeight || '700';
  document.getElementById('ap_cardStyle').value = app.cardStyle || 'soft';
  document.getElementById('ap_radius').value = app.cardRadius || '16';
  const bgSel=document.getElementById('ap_backgroundImage'); bgSel.innerHTML='<option value="">No custom background</option>'+STATE.images.map(f=>{const path=`${MEDIA_FOLDER}/${f.name}`;return `<option value="${escapeAttr(path)}">${escapeHtml(f.name)}</option>`;}).join(''); bgSel.value=app.backgroundImage||'';
  document.getElementById('ap_backgroundOpacity').value=app.backgroundOpacity ?? 0.10;
  document.getElementById('ap_backgroundOverlay').value=app.backgroundOverlay||'#0A0A0B';
  document.getElementById('ap_backgroundPosition').value=app.backgroundPosition||'center';

  const effectsWrap = document.getElementById('effectsWrap');
  effectsWrap.innerHTML = '';
  EFFECT_FIELDS.forEach(([key, label]) => {
    const row = document.createElement('div');
    row.className = 'checkbox-row field';
    row.innerHTML = `<input type="checkbox" id="eff_${key}" ${app.effects[key] ? 'checked' : ''}><label style="margin:0;" for="eff_${key}">${label}</label>`;
    row.querySelector('input').addEventListener('change', (e) => { app.effects[key] = e.target.checked; });
    effectsWrap.appendChild(row);
  });
}

document.getElementById('saveAppearance').addEventListener('click', async () => {
  const app = STATE.appearance;
  app.font = document.getElementById('ap_font').value;
  app.headingWeight = document.getElementById('ap_weight').value;
  app.cardStyle = document.getElementById('ap_cardStyle').value;
  app.cardRadius = document.getElementById('ap_radius').value;
  app.backgroundImage = document.getElementById('ap_backgroundImage').value;
  app.backgroundOpacity = Math.max(0,Math.min(1,Number(document.getElementById('ap_backgroundOpacity').value||0.1)));
  app.backgroundOverlay = document.getElementById('ap_backgroundOverlay').value;
  app.backgroundPosition = document.getElementById('ap_backgroundPosition').value;
  await saveAndToast(PATHS.appearance, app, 'Update appearance');
});
document.getElementById('resetAppearance').addEventListener('click', async () => {
  if(!confirm('Reset appearance to the original Plant Science default?')) return;
  STATE.appearance = JSON.parse(JSON.stringify(APPEARANCE_DEFAULT));
  renderAppearance();
  await saveAndToast(PATHS.appearance, STATE.appearance, 'Reset appearance to default');
});

// =========================================================
// SETTINGS
// =========================================================
function fillSettingsForm(){
  document.getElementById('s_title').value = STATE.site.siteTitle || STATE.site.name || '';
  document.getElementById('s_email').value = STATE.site.email || '';
  document.getElementById('s_linkedin').value = STATE.site.linkedin || '';
  document.getElementById('s_github').value = STATE.site.github || '';
  const cfg = GH.getConfig();
  document.getElementById('g_owner').value = cfg.owner || '';
  document.getElementById('g_repo').value = cfg.repo || '';
  document.getElementById('g_branch').value = cfg.branch || 'main';
  document.getElementById('g_token').value = '';
  document.getElementById('g_token').placeholder = cfg.token ? 'Connected in this browser session — enter a new token only if replacing it' : 'github_pat_…';
}
document.getElementById('saveSettings').addEventListener('click', async () => {
  const currentCfg = GH.getConfig();
  Object.assign(STATE.site, {
    siteTitle: val('s_title'), email: val('s_email'), linkedin: val('s_linkedin'), github: val('s_github')
  });
  GH.setConfig({
    owner: val('g_owner'), repo: val('g_repo'), branch: val('g_branch') || 'main',
    token: document.getElementById('g_token').value.trim() || currentCfg.token
  });
  await saveAndToast(PATHS.site, STATE.site, 'Update settings');
});

document.getElementById('savePasswordBtn').addEventListener('click',async()=>{
  const current=document.getElementById('p_currentPassword').value;
  const pw=document.getElementById('p_newPassword').value;
  const confirmPw=document.getElementById('p_confirmPassword').value;
  const d=STATE.accessData||{};
  if(!current){toast('Enter your current password before changing it.',true);return;}
  let currentOk=false;
  if(d.kdf==='PBKDF2'&&d.salt&&d.passwordHash) currentOk=(await derivePasswordHash(current,d.salt,d.iterations||150000))===d.passwordHash;
  else currentOk=(await sha256Hex(current))===d.passwordHash;
  if(!currentOk){toast('Current password is incorrect.',true);return;}
  if(!pw){toast('For safety, this dashboard does not allow removing the password. Set a new password instead.',true);return;}
  if(pw!==confirmPw){toast('Passwords do not match',true);return;}
  try{
    const salt=randomHex(16); const hash=await derivePasswordHash(pw,salt,150000);
    STATE.accessData={passwordHash:hash,salt,kdf:'PBKDF2',iterations:150000,version:2};
    await GH.putJSON('data/access.json',STATE.accessData,'Update dashboard password');
    document.getElementById('p_currentPassword').value='';document.getElementById('p_newPassword').value='';document.getElementById('p_confirmPassword').value='';
    toast('Password updated ✓');
  }catch(err){toast(err.message,true);}
});

document.getElementById('lockNowBtn').addEventListener('click', () => lockAdmin());
document.getElementById('clearSessionBtn').addEventListener('click', () => { if(confirm('Disconnect the GitHub token from this browser session and lock the dashboard?')){ GH.clear(); lockAdmin(); } });

// ---------------- Init ----------------
initPasswordGate();

// =========================================================
// CUSTOM SECTION BUILDER
// =========================================================
async function saveCustomSections(){
  await GH.putJSON('data/custom-sections.json',{sections:STATE.customSections},'Update custom sections');
  toast('Section saved ✓');
}
function loadCustomSections(){renderCustomSectionsAdmin();}
function renderCustomSectionsAdmin(){
  const wrap=document.getElementById('customSectionsWrap'); if(!wrap)return; wrap.innerHTML='';
  const list=[...STATE.customSections].sort((a,b)=>(a.order??0)-(b.order??0));
  if(!list.length){wrap.innerHTML='<div class="empty-state">No custom sections yet. Add one whenever you need it.</div>';return;}
  list.forEach((sec,i)=>{
    const real=STATE.customSections.indexOf(sec); const card=document.createElement('div');card.className='card custom-section-admin-card';
    card.innerHTML=`<div class="custom-section-admin-head"><div><h2>${escapeHtml(sec.title||'Untitled Section')}</h2><p class="sub">#${escapeHtml(sec.id)} · ${(sec.items||[]).length} item(s) · ${sec.visible===false?'Hidden':'Visible'}</p></div><div class="row-actions"><button class="icon-btn" data-act="up">↑</button><button class="icon-btn" data-act="down">↓</button><button class="icon-btn" data-act="edit">✎</button><button class="icon-btn danger" data-act="del">🗑</button></div></div>`;
    card.querySelector('[data-act=edit]').addEventListener('click',()=>openCustomSectionModal(real));
    card.querySelector('[data-act=del]').addEventListener('click',async()=>{if(confirm(`Delete the section “${sec.title||sec.id}” and all its items?`)){const removedId=STATE.customSections[real]?.id;STATE.customSections.splice(real,1);STATE.customSections.forEach((x,j)=>x.order=j);if(STATE.site.nav?.items)STATE.site.nav.items=STATE.site.nav.items.filter(n=>n.id!==removedId);await saveCustomSections();await GH.putJSON(PATHS.site,STATE.site,'Remove deleted section navigation link');renderCustomSectionsAdmin();fillHeaderForm();}});
    card.querySelector('[data-act=up]').addEventListener('click',async()=>{if(i>0){[list[i-1],list[i]]=[list[i],list[i-1]];list.forEach((x,j)=>x.order=j);STATE.customSections=[...list];await saveCustomSections();renderCustomSectionsAdmin();}});
    card.querySelector('[data-act=down]').addEventListener('click',async()=>{if(i<list.length-1){[list[i+1],list[i]]=[list[i],list[i+1]];list.forEach((x,j)=>x.order=j);STATE.customSections=[...list];await saveCustomSections();renderCustomSectionsAdmin();}});
    const table=document.createElement('table');table.innerHTML='<thead><tr><th>Title</th><th>Subtitle</th><th>Meta</th><th>Actions</th></tr></thead><tbody></tbody>';const body=table.querySelector('tbody');
    (sec.items||[]).sort((a,b)=>(a.order??0)-(b.order??0)).forEach(entry=>{const idx=sec.items.indexOf(entry);const tr=document.createElement('tr');tr.innerHTML=`<td>${escapeHtml(entry.title)}</td><td>${escapeHtml(entry.subtitle)}</td><td>${escapeHtml(entry.meta)}</td><td><div class="row-actions"><button class="icon-btn" data-a="edit">✎</button><button class="icon-btn danger" data-a="del">🗑</button></div></td>`;tr.querySelector('[data-a=edit]').addEventListener('click',()=>openCustomItemModal(sec,idx));tr.querySelector('[data-a=del]').addEventListener('click',async()=>{if(confirm('Delete this item?')){sec.items.splice(idx,1);await saveCustomSections();renderCustomSectionsAdmin();}});body.appendChild(tr);});
    const add=document.createElement('button');add.className='btn btn-outline btn-sm';add.textContent='+ Add item';add.addEventListener('click',()=>openCustomItemModal(sec));card.append(table,add);wrap.appendChild(card);
  });
}
document.getElementById('addCustomSectionBtn').addEventListener('click',()=>openCustomSectionModal());
function openCustomSectionModal(idx){
  const isEdit=idx!==undefined;const sec=isEdit?STATE.customSections[idx]:{id:'new-section',title:'New Section',navLabel:'New Section',heading:'New Section',eyebrow:'',intro:'',emptyText:'Content coming soon.',visible:true,navEnabled:true,order:STATE.customSections.length,items:[]};
  openModal(`<h2>${isEdit?'Edit':'Add'} Custom Section</h2><form id="customSectionForm"><div class="field-row"><div class="field"><label>Section ID</label><input id="cs_id" value="${escapeAttr(sec.id)}" ${isEdit?'readonly':''}></div><div class="field"><label>Navigation label</label><input id="cs_nav" value="${escapeAttr(sec.navLabel||sec.title)}"></div></div><div class="field"><label>Section title</label><input id="cs_title" value="${escapeAttr(sec.title)}"></div><div class="field-row"><div class="field"><label>Eyebrow</label><input id="cs_eyebrow" value="${escapeAttr(sec.eyebrow)}"></div><div class="field"><label>Intro</label><input id="cs_intro" value="${escapeAttr(sec.intro)}"></div></div><div class="field"><label>Empty-state text</label><input id="cs_empty" value="${escapeAttr(sec.emptyText)}"></div><div class="checkbox-row field"><input id="cs_visible" type="checkbox" ${sec.visible!==false?'checked':''}><label style="margin:0;">Show section on public site</label></div><div class="checkbox-row field"><input id="cs_navEnabled" type="checkbox" ${sec.navEnabled!==false?'checked':''}><label style="margin:0;">Show in header navigation</label></div><div class="modal-actions"><button type="button" class="btn btn-outline" id="cancelCS">Cancel</button><button class="btn btn-green">${isEdit?'Save':'Create'} Section</button></div></form>`);
  document.getElementById('cancelCS').onclick=closeModal;document.getElementById('customSectionForm').onsubmit=async e=>{e.preventDefault();const data={...sec,id:val('cs_id').toLowerCase().replace(/[^a-z0-9_-]/g,'-'),navLabel:val('cs_nav'),title:val('cs_title'),heading:val('cs_title'),eyebrow:val('cs_eyebrow'),intro:val('cs_intro'),emptyText:val('cs_empty'),visible:document.getElementById('cs_visible').checked,navEnabled:document.getElementById('cs_navEnabled').checked,items:sec.items||[],order:sec.order??STATE.customSections.length};if(isEdit)STATE.customSections[idx]=data;else STATE.customSections.push(data);STATE.customSections.forEach((x,j)=>x.order=j);await saveCustomSections();renderCustomSectionsAdmin();closeModal();};
}
function openCustomItemModal(sec,idx){
  const isEdit=idx!==undefined;const entry=isEdit?sec.items[idx]:{title:'',subtitle:'',meta:'',description:'',link:'',linkLabel:'View more →',image:'',order:sec.items.length};
  openModal(`<h2>${isEdit?'Edit':'Add'} Item</h2><form id="customItemForm"><div class="field"><label>Title</label><input id="ci_title" value="${escapeAttr(entry.title)}"></div><div class="field-row"><div class="field"><label>Subtitle</label><input id="ci_subtitle" value="${escapeAttr(entry.subtitle)}"></div><div class="field"><label>Meta / year</label><input id="ci_meta" value="${escapeAttr(entry.meta)}"></div></div><div class="field"><label>Image</label><select id="ci_image">${mediaOptions(entry.image)}</select></div><div class="field"><label>Description</label><textarea id="ci_desc">${escapeHtml(entry.description)}</textarea></div><div class="field-row"><div class="field"><label>Link</label><input id="ci_link" value="${escapeAttr(entry.link)}"></div><div class="field"><label>Link label</label><input id="ci_linkLabel" value="${escapeAttr(entry.linkLabel||'View more →')}"></div></div><div class="modal-actions"><button type="button" class="btn btn-outline" id="cancelCI">Cancel</button><button class="btn btn-green">${isEdit?'Save':'Add'} Item</button></div></form>`);
  document.getElementById('cancelCI').onclick=closeModal;document.getElementById('customItemForm').onsubmit=async e=>{e.preventDefault();const data={title:val('ci_title'),subtitle:val('ci_subtitle'),meta:val('ci_meta'),image:val('ci_image'),description:document.getElementById('ci_desc').value.trim(),link:val('ci_link'),linkLabel:val('ci_linkLabel')||'View more →',order:entry.order??sec.items.length};if(isEdit)sec.items[idx]=data;else sec.items.push(data);await saveCustomSections();renderCustomSectionsAdmin();closeModal();};
}

// =========================================================
// OPTIONAL SECTIONS (Publications / Experience / Certificates)
// =========================================================
const SECTION_PATHS = { publications: 'data/publications.json', experience: 'data/experience.json', certificates: 'data/certificates.json' };
const SECTION_DEFS = [
  { key: 'publications', label: 'Publications', fields: { title: 'Title', subtitle: 'Journal / Venue', meta: 'Year', description: 'Description', link: 'Link (DOI / URL)' } },
  { key: 'experience', label: 'Experience', fields: { title: 'Position', subtitle: 'Organization', meta: 'Dates', description: 'Description', link: 'Link (optional)' } },
  { key: 'certificates', label: 'Certificates', fields: { title: 'Title', subtitle: 'Issuing organization', meta: 'Year', description: 'Description', link: 'Link (optional)' } }
];

async function loadOptionalSections(){
  try{
    const cfgRes = await GH.getJSON('data/sections-config.json');
    STATE.sectionsConfig = cfgRes.data || {};
    STATE.sectionItems = {};
    for(const def of SECTION_DEFS){
      const res = await GH.getJSON(SECTION_PATHS[def.key]);
      STATE.sectionItems[def.key] = res.data || [];
    }
    renderOptionalSectionsAdmin();
  }catch(err){ console.warn('Optional sections load failed', err); }
}

function renderOptionalSectionsAdmin(){
  const wrap = document.getElementById('optionalSectionsWrap');
  wrap.innerHTML = '';
  SECTION_DEFS.forEach(def => {
    const cfg = STATE.sectionsConfig[def.key] || { visible: false, order: 0, navLabel: def.label };
    const items = STATE.sectionItems[def.key] || [];
    const card = document.createElement('div');
    card.className = 'card';
    card.innerHTML = `
      <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;">
        <div>
          <h2>${def.label}</h2>
          <p class="sub">${items.length} item${items.length===1?'':'s'} · ${cfg.visible ? 'Visible on site' : 'Hidden'}</p>
        </div>
        <div style="display:flex;align-items:center;gap:14px;">
          <label class="checkbox-row" style="margin:0;"><input type="checkbox" class="sec-toggle" data-key="${def.key}" ${cfg.visible?'checked':''}> Show on site</label>
          <button class="btn btn-green btn-sm sec-add" data-key="${def.key}">+ Add</button>
        </div>
      </div>
      <table style="margin-top:14px;">
        <thead><tr><th>${def.fields.title}</th><th>${def.fields.subtitle}</th><th>${def.fields.meta}</th><th>Actions</th></tr></thead>
        <tbody class="sec-table-body" data-key="${def.key}"></tbody>
      </table>
    `;
    wrap.appendChild(card);
    const body = card.querySelector('.sec-table-body');
    const sorted = [...items].sort((a,b) => (a.order??0)-(b.order??0));
    if(sorted.length === 0){
      body.innerHTML = `<tr><td colspan="4" style="color:var(--d-text-secondary);">No items yet.</td></tr>`;
    }
    sorted.forEach(entry => {
      const realIdx = items.indexOf(entry);
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td>${escapeHtml(entry.title)}</td><td>${escapeHtml(entry.subtitle)}</td><td>${escapeHtml(entry.meta)}</td>
        <td><div class="row-actions">
          <button class="icon-btn" data-act="up">↑</button>
          <button class="icon-btn" data-act="down">↓</button>
          <button class="icon-btn" data-act="edit">✎</button>
          <button class="icon-btn danger" data-act="del">🗑</button>
        </div></td>`;
      tr.querySelector('[data-act=edit]').addEventListener('click', () => openSectionItemModal(def, realIdx));
      tr.querySelector('[data-act=del]').addEventListener('click', async () => {
        if(confirm('Delete this item?')){ items.splice(realIdx,1); await saveSectionItems(def.key); renderOptionalSectionsAdmin(); }
      });
      tr.querySelector('[data-act=up]').addEventListener('click', async () => { swapOrder(items, realIdx, -1); await saveSectionItems(def.key); renderOptionalSectionsAdmin(); });
      tr.querySelector('[data-act=down]').addEventListener('click', async () => { swapOrder(items, realIdx, 1); await saveSectionItems(def.key); renderOptionalSectionsAdmin(); });
      body.appendChild(tr);
    });
    card.querySelector('.sec-toggle').addEventListener('change', async (e) => {
      STATE.sectionsConfig[def.key] = STATE.sectionsConfig[def.key] || { order: 0, navLabel: def.label, heading: def.label, eyebrow: '', emptyText: 'Coming soon.' };
      STATE.sectionsConfig[def.key].visible = e.target.checked;
      try{ await GH.putJSON('data/sections-config.json', STATE.sectionsConfig, `Toggle ${def.label} visibility`); toast(`${def.label} ${e.target.checked ? 'shown' : 'hidden'} ✓`); renderOptionalSectionsAdmin(); }
      catch(err){ toast(err.message, true); }
    });
    card.querySelector('.sec-add').addEventListener('click', () => openSectionItemModal(def));
  });
}

async function saveSectionItems(key){
  try{ await GH.putJSON(SECTION_PATHS[key], STATE.sectionItems[key], `Update ${key}`); toast('Saved ✓'); }
  catch(err){ toast(err.message, true); }
}

function openSectionItemModal(def, idx){
  const items = STATE.sectionItems[def.key];
  const isEdit = idx !== undefined;
  const entry = isEdit ? items[idx] : { title:'', subtitle:'', meta:'', description:'', link:'', order: items.length };
  openModal(`
    <h2>${isEdit?'Edit':'Add'} ${def.label.slice(0,-1) || def.label} Item</h2>
    <form id="secItemForm">
      <div class="field"><label>${def.fields.title}</label><input type="text" id="si_title" value="${escapeAttr(entry.title)}"></div>
      <div class="field-row">
        <div class="field"><label>${def.fields.subtitle}</label><input type="text" id="si_subtitle" value="${escapeAttr(entry.subtitle)}"></div>
        <div class="field"><label>${def.fields.meta}</label><input type="text" id="si_meta" value="${escapeAttr(entry.meta)}"></div>
      </div>
      <div class="field"><label>${def.fields.description}</label><textarea id="si_desc">${escapeHtml(entry.description)}</textarea></div>
      <div class="field"><label>${def.fields.link}</label><input type="text" id="si_link" value="${escapeAttr(entry.link)}"></div>
      <div class="modal-actions">
        <button type="button" class="btn btn-outline" id="cancelSecItem">Cancel</button>
        <button type="submit" class="btn btn-green">${isEdit?'Save':'Add'}</button>
      </div>
    </form>
  `);
  document.getElementById('cancelSecItem').addEventListener('click', closeModal);
  document.getElementById('secItemForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const data = { title: val('si_title'), subtitle: val('si_subtitle'), meta: val('si_meta'), description: document.getElementById('si_desc').value.trim(), link: val('si_link'), order: entry.order };
    if(isEdit) items[idx] = data; else items.push(data);
    await saveSectionItems(def.key);
    renderOptionalSectionsAdmin(); closeModal();
  });
}
