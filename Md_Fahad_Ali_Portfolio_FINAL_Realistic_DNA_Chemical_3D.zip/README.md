# Fahad Badsha Shamim — Portfolio (Portfolio V2)

A public portfolio site + a self-service `/admin` dashboard that edits the site by
committing straight to this GitHub repository. No paid hosting, no database, no
server — just GitHub Pages and the GitHub REST API.

## 1. Create the GitHub repository
1. Go to github.com → **New repository**.
2. Name it (e.g. `portfolio`), keep it **Public**, don't add a README (you already have one).
3. Create the repo.

## 2. Upload these files
**Important:** unzip the file first. Then upload what's *inside* the unzipped
folder (`index.html`, `admin/`, `data/`, `css/`, `js/`, `assets/`, `README.md`)
— not the outer folder itself. If you drag a folder called `portfolio` (or
similar) into GitHub, your site ends up at `yoursite.com/portfolio/` instead of
the root, and GitHub Pages won't find it. The safest way:
1. On your repo's main page, click **Add file → Upload files**.
2. Open the unzipped folder on your computer, select **all files and folders
   inside it** (not the folder itself), and drag them all in together.
3. Commit.

Or with git:
```
git init
git remote add origin https://github.com/<your-username>/<your-repo>.git
git add .
git commit -m "Initial portfolio"
git branch -M main
git push -u origin main
```

## 3. Enable GitHub Pages
1. In your repo: **Settings → Pages**.
2. Under "Build and deployment", set **Source: Deploy from a branch**.
3. Branch: `main`, folder: `/ (root)`. Save.
4. After ~1 minute your site is live at:
   `https://<your-username>.github.io/<your-repo>/`

## 4. Open your portfolio
Visit the URL above. This is the link to put on your CV — it's public and read-only.

## 5. Open the admin dashboard
Go to `https://<your-username>.github.io/<your-repo>/admin/` — keep this link
private (don't put it on your CV).

**First time only — connect your repo:**
1. Create a GitHub **fine-grained personal access token**:
   GitHub → Settings → Developer settings → Personal access tokens → Fine-grained tokens → **Generate new token**.
   - Repository access: **Only select repositories** → choose this repo.
   - Permissions → **Contents: Read and write**.
   - Generate, and copy the token (you won't see it again).
2. In the dashboard's connect screen, enter your GitHub username, repository name,
   branch (`main`), and paste the token. Click **Connect**.

The token is stored only in your browser's local storage — it is never written into
any file in this repository, so it's never exposed on the public site.

## 6. Add / edit research
Admin → **Research** → **Add Research**. Fill in title, category, year, image,
description, tags, links. Use **Edit / Delete / Duplicate / ↑ / ↓** to manage the list.
Changes appear on the public site automatically (usually within 30–90 seconds,
which is how long GitHub Pages takes to rebuild after a commit).

## 7. Change your photo
Admin → **Media Manager** → **Upload Image**. After uploading, click **Set as Hero**
and/or **Set as About** on the image to use it as your portrait in those sections.

## 8. Change colors / background / typography
Admin → **Appearance**:
- Pick a color **preset** (Botanical Green, Ocean Blue, Sage, Earth, Monochrome) or
  fine-tune individual colors with the pickers.
- Choose a **font** and heading weight.
- Choose a **card style** and corner radius.
- Toggle **botanical effects** (line art, leaf silhouettes, grid, dots, particles).
- Click **Save Changes**. Click **Reset to Default** any time to restore the
  original Plant Science theme.

## 9. Update education
Admin → **Education** → **Add Education**, or edit/reorder/delete existing entries.

## 10. Update skills
Admin → **Skills** → **Add Category**, then type a skill name and press **Enter**
inside a category to add it. Click ✕ on a chip to remove a skill.

## 11. Manage media
Admin → **Media Manager** lists every image in `assets/images/`. You can filter by
category, copy an image's path (to paste into a Research/Education image field),
or delete unused images.

## 12. Settings
Admin → **Settings** — site title, email, social links, and your GitHub connection
(owner/repo/branch/token). **Disconnect** removes the saved connection from this
browser only (your repo/site are untouched).

---

## How it works (technical notes)

- **Public site** (`index.html`) reads the JSON files in `data/` with plain
  `fetch()` — no token needed, works on any static host.
- **Admin dashboard** (`admin/index.html`) reads and writes those same JSON files
  through the GitHub Contents API, using the token you enter once per browser.
- Uploaded images are committed into `assets/images/` the same way.
- Every save updates `data/site.json`'s `lastUpdated` field, shown on the dashboard
  Overview.
- **Security**: the token lives only in `localStorage` in your browser. It is never
  committed to the repository or shipped in any JS file, so the public site never
  exposes credentials. Use a fine-grained token scoped to only this repo with
  Contents read/write — nothing more — so a leaked token has minimal blast radius.
  Keep the `/admin` URL private since anyone who knows it could see the (empty)
  connect screen — but without your token, they cannot save changes.

## Optional sections (Publications / Experience / Certificates)
Admin → **Optional Sections**. Each one has a "Show on site" toggle — turn it on
and it appears on the public site and in the navigation automatically, in the
order Publications → Experience → Certificates. Add/edit/delete/reorder items
the same way as Research. Turning a section off hides it but keeps its content,
so you can turn it back on later without re-entering anything.

*(Note: this covers the common cases — a fixed set of ready-made section types
you can turn on, fill in, and reorder. It's intentionally not a fully generic
"create any section with any name" page builder — that would need a real backend
to stay reliable, which goes beyond what a free static GitHub Pages site can do
safely.)*

## Optional dashboard password
Admin → **Settings** → **Dashboard password**. Set a password here to add a
casual gate on `/admin` (asks for it once per browser, until you click **Lock
dashboard now** or clear site data). Leave both fields blank and save to remove
it. **This is not real security** — it's a simple deterrent for anyone who
stumbles on the link, not protection against someone who actually wants in.
Your real protection is your GitHub token, which lives only in your browser.

## File structure
```
/
├── index.html              → public portfolio
├── admin/index.html        → admin dashboard (keep this link private)
├── data/                   → all editable content (JSON)
├── assets/images/          → uploaded photos
├── css/                    → style.css (public site), dashboard.css (admin)
└── js/                     → main.js, data.js (public site)
                               github-api.js, dashboard.js (admin)
```

## Security & update workflow (v3)

This project is designed for free GitHub Pages with no backend.

### Important security model

GitHub Pages cannot provide true server-side authentication for `/admin`. The dashboard therefore uses multiple practical protections:

- Admin password is stored as a salted PBKDF2 hash (150,000 iterations) in `data/access.json` after first-run setup.
- Existing SHA-256 password hashes remain backward-compatible so an existing installation is not locked out.
- Admin unlock state is stored in `sessionStorage`, not persistent `localStorage`.
- The dashboard automatically locks after 20 minutes without activity.
- The GitHub Personal Access Token is stored only in `sessionStorage` for the current browser session.
- Repository/branch configuration is stored without the token.
- Disconnect/clear-session removes the GitHub token immediately.
- The token is never written into repository files, JSON content, HTML, CSS, JavaScript, URLs, or console output.
- Use a fine-grained GitHub token limited to this portfolio repository with only `Contents: Read and write` (GitHub may require `Metadata: Read-only`) and a short expiry such as 30 days.

A technically skilled person can still inspect a static GitHub Pages site's source. Do not treat the client-side password as bank-grade security. The strongest protection is to keep the GitHub token private, tightly scoped, short-lived, and revoked when you finish editing.

### Updating safely

1. Open `/admin`.
2. Enter the admin password.
3. Connect a fresh fine-grained GitHub token when needed.
4. Edit content, images, sections, navigation, and appearance.
5. Commit the changes from the dashboard.
6. Check the live GitHub Pages site.
7. Disconnect the token in the dashboard.
8. Revoke/delete the token in GitHub.
9. Lock/logout the dashboard.

### Media

Images are managed from the dashboard and committed to `assets/images/`. The Media Manager can upload, replace, assign, preview, and safely delete images. It also clears broken references before deleting an assigned image.

### Custom sections

`data/custom-sections.json` stores sections created from the dashboard. Sections can be added, renamed, hidden, reordered, edited, and deleted. Visible custom sections automatically appear in the public navigation unless navigation is disabled.
